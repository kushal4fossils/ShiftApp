var _ = require('underscore');

module.exports = function (req, res, next) {
    var crudModel = req.params.entity;
    var viewerRole = crudModel+".viewer";
    var editorRole = crudModel+".editor";
    var adminRole = crudModel+".admin";

    if(!req.admin.id || !req.admin.roles || !_.find(req.admin.roles, function(role){
            return role === viewerRole || role === editorRole || role === adminRole;
        }))
        return next({
            code: 'NOT_AUTHORIZED',
            msg: 'Permission denied'
        });

    return next();
};
