var async = require('async');
var jwt = require('jsonwebtoken');
var _ = require('underscore');
var config = require('./../../config');
var mongoDb = require('./../../config/db').mongo;

var tokenToEntityMap = {
    utoken: {
        collection: 'users',
        type: 'user'
    }
};
module.exports = function(req, res, next){
    var token = req.headers.token;
    var entity = tokenToEntityMap['utoken'];

    async.auto({
        validateToken: function(cb){
            jwt.verify(token, config.CONSTANTS.jwtSecret, function(err, payload){
                if(err)
                    return cb(err);
                return cb(null, payload);
            })
        },
        entity: ['validateToken', function(results, cb){
            var dbCol = mongoDb.get(entity.collection);
            dbCol.findOne({
                uuid: results.validateToken.userId
            },{}, function(err, matchedEntity){
                if(err)
                    return cb(err);
                if(!matchedEntity)
                    return cb({
                        code: 'BAD_REQUEST',
                        msg: 'Invalid user'
                    });
                if(matchedEntity.accessToken !== token)
                    return cb({
                        code: 'NOT_AUTHORIZED',
                        msg: 'Could not be authorized'
                    });

                var keysToPick = ['uuid', 'isAdmin', 'isEmployee', 'companyId', 'email'];

                req[entity.type] = _.pick(matchedEntity,keysToPick);
                return cb(null, matchedEntity);
            });
        }]
    }, function(err, results){
        if(err)
            return res.notAuthorized({
                code: 'NOT_AUTHORIZED',
                msg: 'Could not be authorized'
            });

        return next();
    });

};