var _ = require('underscore');

module.exports = function (req, res, next) {
    if(!req.user || !req.user.isAdmin)
        return next({
            code: 'NOT_AUTHORIZED',
            msg: 'Permission denied'
        });

    return next();
};
