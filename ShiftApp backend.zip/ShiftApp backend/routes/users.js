var express = require('express');
var router = express.Router();

var isAuthenticated = require('./accessControls/isAuthenticated');

var userController = require('./../controllers/userController');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/me', [isAuthenticated], userController.me);
router.post('/signup', userController.signUp);
router.post('/authenticate', userController.login);
router.post('/device',[isAuthenticated], userController.addDevice);

module.exports = router;
