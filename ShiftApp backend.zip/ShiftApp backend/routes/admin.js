var express = require('express');
var router = express.Router();

var isAuthenticated = require('./accessControls/isAuthenticated');
var isAdmin = require('./accessControls/isAdmin');

var adminController = require('./../controllers/adminController');

router.post('/shift/add', [isAuthenticated, isAdmin], adminController.addShift);
router.post('/shift/parse', [isAuthenticated, isAdmin], adminController.parseShift);
router.post('/shift/assign', [isAuthenticated, isAdmin], adminController.assignShift);

module.exports = router;
