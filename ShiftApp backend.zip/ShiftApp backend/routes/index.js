var express = require('express');
var router = express.Router();

var isCrudAdmin = require("./accessControls/isCrudAdmin");
var isCrudViewer = require("./accessControls/isCrudViewer");
var isCrudEditor = require("./accessControls/isCrudEditor");
var isAuthenticated = require('./accessControls/isAuthenticated');

var crud = require('./../controllers/crudController');
var search = require('./../controllers/searchController');
var shift = require('./../controllers/shiftController');
var authenticateController = require('./../controllers/authenticateController');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

//crud routes
router.post('/crud/:entity', [isCrudAdmin], crud.create);
router.get('/crud/:entity', [isCrudViewer], crud.readList);
router.get('/crud/:entity/:entityId', [isCrudViewer], crud.readDetails);
router.put('/crud/:entity/:entityId', [isCrudEditor], crud.update);
router.delete('/crud/:entity/:entityId', [isCrudAdmin], crud.deleteRecord);

router.get('/employee', [isAuthenticated], search.employeeList);
router.get('/employee/:id', [isAuthenticated], search.employeeDetails);

router.get('/me/shift', [], shift.list);
router.get('/shift', [isAuthenticated], shift.listAll);
router.post('/shift/:id/request/unassign', shift.requestUnassign);
router.post('/shift/:id/request/assign', shift.requestAssign);



router.post('/availabilty', shift.addAvailability);
router.get('/availabilty', shift.getAvailability);
module.exports = router;
