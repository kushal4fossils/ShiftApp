var express = require('express');
var router = express.Router();

var isAuthenticated = require('./accessControls/isAuthenticated');
var isAdmin = require('./accessControls/isAdmin');

var companyController = require('./../controllers/companyController');


router.post('/join', [isAuthenticated], companyController.joinCompany);
router.put('/join/requests/:id/withdraw', [isAuthenticated], companyController.withdrawJoinRequest);
router.post('/create', [isAuthenticated], companyController.createCompany);

router.get('/join/requests', [isAuthenticated, isAdmin], companyController.getJoinRequestList);
router.get('/join/requests/:id', [isAuthenticated, isAdmin], companyController.getJoinRequest);
router.put('/join/requests/:id/approve', [isAuthenticated, isAdmin], companyController.approveJoinRequest);
router.put('/join/requests/:id/decline', [isAuthenticated, isAdmin], companyController.declineJoinRequest);


module.exports = router;
