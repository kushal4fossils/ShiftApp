var async = require('async');
var _ = require('underscore');
var jwt = require('jsonwebtoken');
var utils = require('./../services/utils');
var config = require('./../config');
var mongoDb = require('./../config/db').mongo;

var companyController = {
    createCompany: function(req, res){
        if(!req.body.name)
            return res.sendError({
                code: 'BAD_REQUEST',
                msg: 'invalid name'
            });

        var companies = mongoDb.get('companies');
        var users = mongoDb.get('users');

        async.auto({
            check: function(asyncCB){
                companies.findOne({
                    name: req.body.name
                }, {}, function(err, companyDoc){
                    if(err)
                      return asyncCB(err);

                    if(companyDoc)
                      return asyncCB({
                          code: "BAD_REQUEST",
                          msg: 'name already taken. please try a different name'
                      });

                    return asyncCB();
                });
            },
            userCheck: function(asyncCB){
                users.findOne({
                    uuid: req.user.uuid,
                    isAdmin: false,
                    isEmployee: false,
                }, {}, function(err, userDoc){
                    if(err)
                      return asyncCB(err);

                    if(!userDoc)
                      return asyncCB({
                          code: 'BAD_REQUEST',
                          msg: 'invalid operation'
                      });

                    return asyncCB(null, userDoc);
                });
            },
            create:['check', 'userCheck', function(results, asyncCB){
                var toInsert = {
                    uuid: utils.uuid(),
                    name: req.body.name,
                    isActive: true,
                    createdAt: new Date(),
                    updatedAt: new Date(),
                    createdBy: req.user.uuid,
                    joinCode: utils.getAlphabetOTP(3) + utils.getIntOTP(3)
                };

                companies.insert(toInsert, asyncCB);

            }],
            updateUser: ['create', function(results, asyncCB){
                users.findOneAndUpdate({
                    uuid: req.user.uuid
                }, {
                    $set: {
                        isAdmin: true,
                        companyId: results.create.uuid
                    }
                }, {}, asyncCB);
            }]
        }, function(err, results){
            if(err)
              return res.sendError(err);

            return res.ok({
                success: true,
                company: results.create
            });
        });
    },

    joinCompany: function(req, res){
        if(!req.body.code)
            return res.sendError({
                code: 'BAD_REQUEST',
                msg: 'invalid code'
            });

        var companies = mongoDb.get('companies');
        var users = mongoDb.get('users');
        var joinRequests = mongoDb.get('joinRequests');

        async.auto({
            check: function(asyncCB){
                companies.findOne({
                    joinCode: req.body.code
                }, {}, function(err, companyDoc){
                    if(err)
                        return asyncCB(err);

                    if(!companyDoc)
                        return asyncCB({
                            code: "BAD_REQUEST",
                            msg: 'invalid join code'
                        });

                    return asyncCB(null, companyDoc);
                });
            },
            userCheck: function(asyncCB){
                users.findOne({
                    uuid: req.user.uuid,
                    isAdmin: false,
                    isEmployee: false,
                    joinRequested: {$ne: true}
                }, {}, function(err, userDoc){
                    if(err)
                        return asyncCB(err);

                    if(!userDoc)
                        return asyncCB({
                            code: 'BAD_REQUEST',
                            msg: 'invalid operation'
                        });

                    return asyncCB(null, userDoc);
                });
            },
            requestJoin:['check', 'userCheck', function(results, asyncCB){
                var toInsert = {
                    uuid: utils.uuid(),
                    user: req.user.uuid,
                    company: results.check.uuid,
                    status: 'PENDING',
                    createdAt: new Date(),
                    updatedAt: new Date()
                };

                joinRequests.insert(toInsert, asyncCB);
            }],
            join:['check', 'userCheck', function(results, asyncCB){
                users.findOneAndUpdate({
                    uuid: req.user.uuid
                }, {
                    $set: {
                        //isEmployee: true,
                        joinRequest: 'PENDING'
                        //companyId: results.check.uuid
                    }
                }, {}, asyncCB);
            }]
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: true,
                company: results.check,
                joinRequest: results.requestJoin
            });
        });
    },

    getJoinRequestList: function(req, res){
        var joinRequests = mongoDb.get('joinRequests');
        async.auto({
            requests: function(asyncCB){
                joinRequests.find({
                    company: req.user.companyId,
                    status: 'PENDING',
                }, {}, asyncCB);
            }
        }, function(err, results){
            if(err)
              return res.sendError(err);

            return res.ok({
                success: true,
                data: results.requests
            });
        });
    },

    getJoinRequest:function(req, res){
        var reqId = req.params.id;
        var joinRequests = mongoDb.get('joinRequests');
        async.auto({
            request: function(asyncCB){
                joinRequests.findOne({
                    uuid: reqId,
                    company: req.user.companyId,
                    status: 'PENDING',
                }, {}, asyncCB);
            }
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: true,
                data: results.requests
            });
        });
    },

    approveJoinRequest: function(req, res){
        var reqId = req.params.id;
        var joinRequests = mongoDb.get('joinRequests');
        async.auto({
            requestCheck: function(asyncCB){
                joinRequests.findOne({
                    uuid: reqId,
                    company: req.user.companyId,
                    status: 'PENDING',
                }, {}, function(err, requestDoc){
                    if(err)
                      return asyncCB(err);

                    if(!requestDoc)
                      return asyncCB({
                          code: 'NOT_FOUND',
                          msg: 'invalid request id'
                      });

                    return asyncCB(null, requestDoc);
                });
            },
            company: function(asyncCB){
                var companies = mongoDb.get('companies');
                companies.findOne({
                    uuid: req.user.companyId
                }, function(err, companyRes){
                    if(err)
                      return asyncCB(err);

                    if(!companyRes)
                      return asyncCB({
                          code: 'NOT_FOUND',
                          msg: ''
                      });

                    return asyncCB(null, companyRes);
                })
            },
            approve:['requestCheck', function(results, asyncCB){
                joinRequests.findOneAndUpdate({
                    uuid: reqId,
                    company: req.user.companyId,
                    status: 'PENDING',
                }, {
                    $set: {
                        status: 'APPROVED',
                        approvedBy: req.user.uuid,
                        approvedAt: new Date(),
                        updatedAt: new Date()
                    }
                }, function(err, requestDoc){
                    if(err)
                        return asyncCB(err);

                    if(!requestDoc)
                        return asyncCB({
                            code: 'NOT_FOUND',
                            msg: 'invalid request id'
                        });

                    return asyncCB(null, requestDoc);
                });
            }],
            join:['approve', function(results, asyncCB){
                var users = mongoDb.get('users');
                users.findOneAndUpdate({
                    uuid: req.user.uuid
                }, {
                    $set: {
                        isEmployee: true,
                        joinRequest: 'APPROVED',
                        companyId: results.requestCheck.company
                    }
                }, {}, asyncCB);
            }]
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: true,
                company: results.company
            });
        });
    },

    declineJoinRequest: function(req, res){
        var reqId = req.params.id;
        var joinRequests = mongoDb.get('joinRequests');
        async.auto({
            requestCheck: function(asyncCB){
                joinRequests.findOne({
                    uuid: reqId,
                    company: req.user.companyId,
                    status: 'PENDING',
                }, {}, function(err, requestDoc){
                    if(err)
                        return asyncCB(err);

                    if(!requestDoc)
                        return asyncCB({
                            code: 'NOT_FOUND',
                            msg: 'invalid request id'
                        });

                    return asyncCB(null, requestDoc);
                });
            },
            company: function(asyncCB){
                var companies = mongoDb.get('companies');
                companies.findOne({
                    uuid: req.user.companyId
                }, function(err, companyRes){
                    if(err)
                        return asyncCB(err);

                    if(!companyRes)
                        return asyncCB({
                            code: 'NOT_FOUND',
                            msg: ''
                        });

                    return asyncCB(null, companyRes);
                })
            },
            decline:['requestCheck', function(results, asyncCB){
                joinRequests.findOneAndUpdate({
                    uuid: reqId,
                    company: req.user.companyId,
                    status: 'PENDING',
                }, {
                    $set: {
                        status: 'DECLINED',
                        declinedBy: req.user.uuid,
                        declinedAt: new Date(),
                        updatedAt: new Date()
                    }
                }, function(err, requestDoc){
                    if(err)
                        return asyncCB(err);

                    if(!requestDoc)
                        return asyncCB({
                            code: 'NOT_FOUND',
                            msg: 'invalid request id'
                        });

                    return asyncCB(null, requestDoc);
                });
            }],
            join:['approve', function(results, asyncCB){
                var users = mongoDb.get('users');
                users.findOneAndUpdate({
                    uuid: req.user.uuid
                }, {
                    $set: {
                        joinRequest: 'DECLINED',
                    }
                }, {}, asyncCB);
            }]
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: true,
                company: results.company
            });
        });
    },

    withdrawJoinRequest: function(req, res){
        var reqId = req.params.id;
        var joinRequests = mongoDb.get('joinRequests');
        async.auto({
            requestCheck: function(asyncCB){
                joinRequests.findOne({
                    uuid: reqId,
                    //company: req.user.companyId,
                    status: 'PENDING',
                    user: req.user.uuid
                }, {}, function(err, requestDoc){
                    if(err)
                        return asyncCB(err);

                    if(!requestDoc)
                        return asyncCB({
                            code: 'NOT_FOUND',
                            msg: 'invalid request id'
                        });

                    return asyncCB(null, requestDoc);
                });
            },
            company: ['requestCheck', function(results, asyncCB){
                var companies = mongoDb.get('companies');
                companies.findOne({
                    uuid: results.requestCheck.company
                }, function(err, companyRes){
                    if(err)
                        return asyncCB(err);

                    if(!companyRes)
                        return asyncCB({
                            code: 'NOT_FOUND',
                            msg: ''
                        });

                    return asyncCB(null, companyRes);
                })
            }],
            withdraw:['requestCheck', function(results, asyncCB){
                joinRequests.findOneAndUpdate({
                    uuid: reqId,
                    //company: req.user.companyId,
                    status: 'PENDING',
                    user: req.user.uuid
                }, {
                    $set: {
                        status: 'WITHDRAWN',
                        declinedBy: req.user.uuid,
                        declinedAt: new Date(),
                        updatedAt: new Date()
                    }
                }, function(err, requestDoc){
                    if(err)
                        return asyncCB(err);


                    if(!requestDoc)
                        return asyncCB({
                            code: 'NOT_FOUND',
                            msg: 'invalid request id'
                        });



                    return asyncCB(null, requestDoc);
                });
            }],
            setStatus:['withdraw', function(results, asyncCB){
                var users = mongoDb.get('users');
                users.findOneAndUpdate({
                    uuid: req.user.uuid,

                }, {
                    $set: {
                        joinRequest: 'WITHDRAWN',
                    }
                }, {}, asyncCB);
            }]
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: true,
                company: results.company
            });
        });
    }
};

module.exports = companyController;