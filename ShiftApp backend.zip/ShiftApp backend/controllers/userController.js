var async = require('async');
var _ = require('underscore');
var jwt = require('jsonwebtoken');
var utils = require('./../services/utils');
var loginService = require('./../services/loginService');
var config = require('./../config');

var mongoDb = require('./../config/db').mongo;

var userHiddenFields = ['_id', 'password', 'aToken'];

var userController = {
    signUp:function(req, res){
        if(!req.body.email || !req.body.password)
          return res.sendError({
              code: 'BAD_REQUEST',
              msg: 'Required fields missing'
          });

        async.auto({
            check: function(cb){
                var users = mongoDb.get('users');
                users.findOne({
                    email: req.body.email
                }, function(err, userDoc){
                    if(err)
                      return cb(err);

                    if(userDoc)
                      return cb({
                          code: 'BAD_REQUEST',
                          msg: 'Already Registered'
                      });

                    return cb(null, userDoc);
                });
            },
            create:['check', function(results, cb){
                var users = mongoDb.get('users');
                var toInsert = {
                    uuid: utils.uuid(),
                    email: req.body.email,
                    password: utils.hashPassword(req.body.password),
                    isAdmin: false,
                    isEmployee: false,
                    createdAt: new Date()
                };
                users.insert(toInsert, cb);
            }],
            login:['create', function(results, cb){
                loginService.login('user', req.body, cb);
            }]
        }, function(err, results){
            if(err)
              return res.sendError(err);

            return res.ok({
                success: true,
                user: _.pick(results.create, 'uuid', 'email', 'isAdmin', 'isEmployee'),
                token: results.login.accessToken
            });
        });
    },

    login:function (req, res){
        async.auto({
            login: function(cb){
                loginService.login('user', req.body, cb);
            },
            user: ['login', function(results, cb){
                var users = mongoDb.get('users');
                users.findOne({
                    email: req.body.email
                }, function(err, userDoc){
                    if(err)
                        return cb(err);

                    return cb(null, userDoc);
                });
            }]
        }, function(err, results){
            if(err)
              return res.sendError(err);

            return res.ok({
                success: true,
                user: _.pick(results.user, 'uuid', 'email', 'isAdmin', 'isEmployee', 'joinRequest'),
                token: results.login.accessToken
            });
        });

    },

    logout:function (req, res){
        loginService.logout('user', req.vendor, function(err, logoutObj){
            if(err){
                if(err.code && err.code === 'NOT_FOUND'){
                    return res.notFound(err);
                }
                if(err.code && err.code === 'BAD_REQUEST'){
                    return res.badRequest(err);
                }
                return res.serverError(err);
            }

            return res.ok(logoutObj);
        });
    },

    initiateReset: function(req, res){
        var username = req.params.username;
        loginService.initiateReset('user', username, function(err, initateDoc){
            if(err){
                if(err.code && err.code === 'NOT_FOUND'){
                    return res.notFound(err);
                }
                if(err.code && err.code === 'BAD_REQUEST'){
                    return res.badRequest(err);
                }
                return res.serverError(err);
            }

            return res.ok(initateDoc);
        });
    },

    setNewPassword: function(req, res){
        var username = req.params.username;
        var otp = req.body.otp;
        var password = req.body.password;

        loginService.newPassword('user', username,  otp, password, function(err, initateDoc){
            if(err){
                if(err.code && err.code === 'NOT_FOUND'){
                    return res.notFound(err);
                }
                if(err.code && err.code === 'BAD_REQUEST'){
                    return res.badRequest(err);
                }
                return res.serverError(err);
            }

            return res.ok(initateDoc);
        });
    },

    me: function(req, res){

        async.auto({
            user: function(callback){
                var users = mongoDb.get('users');
                users.findOne({
                    uuid: req.user.uuid
                }, {
                    fields: {
                        uuid: 1,
                        email: 1,
                        isAdmin: 1,
                        isEmployee: 1,
                        joinRequest: 1,
                        companyId: 1,

                    }
                }, function(err, userDoc){
                    if(err)
                        return callback(err);

                    return callback(null, userDoc);
                });
            },
            company: ['user', function(results, callback){
                if(!results.user.companyId){
                    return callback();
                }
                var companies = mongoDb.get('companies');
                companies.findOne({
                    uuid: results.user.companyId
                }, {
                    fields: {
                        name: 1,
                        uuid: 1,
                        joinCode: 1
                    }
                }, function(err, companyDoc){
                    if(err)
                        return callback(err);

                    return callback(null, companyDoc);
                });
            }]
        }, function(err, results){
            if(err)
                return res.sendError(err);

            var toReturn = results.user;
            toReturn.company = results.company;

            return res.ok({
                success: true,
                data: toReturn
            });
        });
    },

    addDevice: function(req, res){
        var userDeviceData = mongoDb.get('userDeviceData');

        if(!req.body.deviceId || !req.body.deviceData){
            return res.sendError({
                code: 'BAD_REQUEST',
                msg: 'Invalid request'
            });
        }

        userDeviceData.findOneAndUpdate({
            uuid: req.user.uuid,
        },{
            $set: {
                deviceId: req.body.deviceId,
                deviceData: {
                    $push: req.body.deviceData
                }
            }
        }, {
            upsert: true
        }, function(err, updatedDoc){
            if(err)
                return res.serverError(err);

            return res.ok({
                msg: 'successfully updated'
            });
        });
    }
};

module.exports = userController;