var async = require('async');
var _ = require('underscore');

//var crudService = require('./../services/crud');

var crud = {
    create: function(req, res){
        var entity = req.params.entity;
        var toInsert = req.body;

        crudService.createEntity(entity, toInsert, function(err, insertedDoc){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: insertedDoc
            });
        });

    },

    readList: function(req, res){
        var entity = req.params.entity;
        var entityId = req.params.entityId;
        var limit = req.query.limit || 100;
        var skip = req.query.skip || 0;

        var qString = req.query.q || '';
        var searchArr = qString.split(',');

        var searchCriteria = {};

        _.each(searchArr, function(item){
            var temp = item.split(":");
            if(!temp || temp.length < 2)
                return;
            var val = temp[1].trim();
            var key = temp[0].trim();
            if(val === 'false')
                val = false;
            if(val === 'true')
                val = true;
            searchCriteria[key] = val;
        });

        crudService.fetchList(entity, searchCriteria, skip, limit, function(err, docs){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: docs
            });
        });

    },

    readDetails: function(req, res){
        var entity = req.params.entity;
        var entityId = req.params.entityId;

        crudService.fetchDetails(entity, entityId, function(err, doc){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: doc
            });
        });
    },

    update: function(req, res){
        var entity = req.params.entity;
        var entityId = req.params.entityId;

        var updateObj = req.body;

        crudService.updateEntity(entity, entityId, updateObj, function(err, doc){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: doc
            });
        });

    },

    deleteRecord: function(req, res){
        var entity = req.params.entity;
        var entityId = req.params.entityId;

        crudService.deleteEntity(entity, entityId, function(err, doc){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: doc
            });
        });
    }
};

module.exports = crud;