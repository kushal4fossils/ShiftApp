var async = require('async');
var _ = require('underscore');

var mongoDb = require('./../config/db').mongo;

var shift = {
    list: function(req, res){
        async.auto({
            shiftList: function(cb){
                var shifts = mongoDb.get('shifts');

                shifts.find({
                    assigneeId: req.empId
                }, {
                    fields: {
                        date: 1,
                        startTime: 1,
                        endTime: 1,
                        status: 1
                    }
                }, cb);
            }
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: [
                    {
                        date: new Date("2019-01-10"),
                        startTime: "15:30",
                        endTime: "18:00",
                        assigneeId: 1,
                        assigneeName: 'Tuhin'
                    },
                ]
            });
        });
    },

    listAll: function(req, res){
        async.auto({
            shiftList: function(cb){
                var shifts = mongoDb.get('shifts');

                shifts.find({
                    companyId: req.user.companyId,
                    startTime: {$gte: new Date()}
                }, {
                    fields: {
                        date: 1,
                        startTime: 1,
                        endTime: 1,
                        status: 1
                    }
                }, cb);
            }
        }, function(err, results){
            if(err)
                return res.sendError(err);

            var statusCounts = _.countBy(results, function(item){
                return item.status;
            });
            return res.ok({
                success: "true",
                statusCounts: statusCounts,
                data: results
            });
        });
    },

    requestUnassign: function(req, res){
        async.auto({
            shift: function(cb){
                var shifts = mongoDb.get('shifts');

                shifts.find({
                    id: req.params.id
                }, {
                    status: 'CALLED_OUT'
                }, {
                    fields: {
                        date: 1,
                        startTime: 1,
                        endTime: 1
                    }
                }, cb);
            }
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: results.shift
            });
        });
    },

    requestAssign: function(req, res){
        async.auto({
            shift: function(cb){
                var shiftsCalledIn = mongoDb.get('shiftsCalledIn');

                shiftsCalledIn.insert({
                    shiftId: req.params.id,
                    empId: req.empId
                }, {}, cb);
            }
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: results.shift
            });
        });
    },

    addAvailability: function(req, res){
        async.auto({
            availibility: function(cb){
                var availability = mongoDb.get('availability');

                availability.insert({
                    empId: req.empId,
                    date: req.body.date,
                    startTime: req.body.startTime,
                    endTime: req.body.endTime
                }, {}, cb);
            }
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: results.availibility
            });
        });
    },

    getAvailability: function(req, res){
        async.auto({
            availability: function(cb){
                var availability = mongoDb.get('availability');

                availability.find({
                    endTime: {
                        $gte: new Date()
                    }
                }, {}, cb);
            }
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: results.availability
            });
        });
    }
};

module.exports = shift;