var async = require('async');
var _ = require('underscore');
var jwt = require('jsonwebtoken');
var utils = require('./../services/utils');
var config = require('./../config');
var mongoDb = require('./../config/db').mongo;

var adminController = {
    addShift: function(req, res){
        //TODO: add shifts to db,


        return res.ok({
            status: "success",
            data: req.body.tasks
        });

    },

    parseShift: function(req, res){
        //TODO: parse image doc to extract shifts

        return res.ok({
            status: "success",
            data: [
                {
                    date: new Date("2019-01-10"),
                    startTime: "15:30",
                    endTime: "18:00",
                    assigneeId: 1,
                    assigneeName: 'Tuhin'
                },
                {
                    date: new Date("2019-01-10"),
                    startTime: "18:00",
                    endTime: "20:00",
                    assigneeId: 2,
                    assigneeName: 'Tirtha'
                },

            ]
        });

    },

    assignShift: function(req, res){
        //TODO: add shifts to db,


        return res.ok({
            status: "success",
            data: req.body.tasks
        });

    }
};

module.exports = adminController;