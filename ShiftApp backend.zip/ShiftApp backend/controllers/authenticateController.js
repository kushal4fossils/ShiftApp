var async = require('async');
var _ = require('underscore');

var authenticate = {
    signUp: function(req, res){
        async.auto({
            check: function(cb){
                var users = req.db.get('users');

                users.findOne({
                    email: req.body.email
                }, function(err, userDoc){
                    if(err)
                      return cb(err);

                    if(userDoc){
                        return cb({
                            code: 'BAD_REQUEST',
                            msg: 'Already registered'
                        });
                    }

                    return cb(null, userDoc);
                });
            }
        }, function(err, results){
            if(err)
              return res.sendError(err);

            return res.ok({
                success: true
            });
        });
    }
};

module.exports = authenticate;