var async = require('async');
var _ = require('underscore');

var mongoDb = require('./../config/db').mongo;

var search = {
    employeeList: function(req, res){
        async.auto({
            employee: function(cb){
                var employee = mongoDb.get('employee');

                employee.find({}, {
                    fields: {
                        name: 1,
                    }
                }, cb);
            }
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: results.employee
            });
        });
    },

    employeeDetails: function(req, res){
        async.auto({
            employee: function(cb){
                var employee = mongoDb.get('employee');

                employee.findOne({
                    empId: req.params.id
                }, {
                    fields: {
                        name: 1,
                    }
                }, cb);
            }
        }, function(err, results){
            if(err)
                return res.sendError(err);

            return res.ok({
                success: "true",
                data: results.employee
            });
        });
    }
};

module.exports = search;