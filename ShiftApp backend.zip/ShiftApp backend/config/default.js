var config = {
    CONSTANTS: {
        limit: 10,
        from: 0,
        jwtSecret: 'stylegig@jwtsecret',
    },
};

module.exports = config;