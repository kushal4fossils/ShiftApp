var config = {
    ENV_NAME: 'development',
    baseUrl: 'https://dev.shiftapp.com',
    mongo_db: {
        host: "shiftapp-shard-00-00-nhahq.mongodb.net:27017,shiftapp-shard-00-01-nhahq.mongodb.net:27017,shiftapp-shard-00-02-nhahq.mongodb.net:27017",
        database: 'staging',
        username: 'apiShift',
        password: 'erubLHfPkITPSZqB',
        queryParams: 'ssl=true&replicaSet=ShiftApp-shard-0&authSource=admin&retryWrites=true'
    }
};

config.mongo_db.uri = "mongodb://" + config.mongo_db.username + ":"+ config.mongo_db.password + "@" + config.mongo_db.host + "/" + config.mongo_db.database + "?"+ config.mongo_db.queryParams;

module.exports = config;