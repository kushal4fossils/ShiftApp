var ocrService = {
    getShiftDetails: function(image, callback){
        //TODO: parse image to get shift details
    }
};

module.exports = ocrService;