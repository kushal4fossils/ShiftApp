var models = require('./models/compiled');

var crudService = {
    fetchList: function(entityType, filterParams, skip, limit, callback){
        if(!models[entityType])
            return callback({
                code: 'BAD_REQUEST',
                msg: 'invalid entityType'
            });

        models[entityType].find(filterParams, skip, limit, callback);
    },

    fetchDetails: function(entityType, entityId, callback){
        if(!models[entityType])
            return callback({
                code: 'BAD_REQUEST',
                msg: 'invalid entityType'
            });

        models[entityType].findByPrimaryKey(entityId, callback);
    },

    deleteEntity: function(entityType, entityId, callback){
        if(!models[entityType])
            return callback({
                code: 'BAD_REQUEST',
                msg: 'invalid entityType'
            });

        models[entityType].deleteByPrimaryKey(entityId, callback);
    },

    createEntity: function(entityType, entityObj, callback){
        if(!models[entityType])
            return callback({
                code: 'BAD_REQUEST',
                msg: 'invalid entityType'
            });

        models[entityType].insert(entityObj, callback);
    },

    updateEntity: function(entityType, entityId, updateObj, callback){
        if(!models[entityType])
            return callback({
                code: 'BAD_REQUEST',
                msg: 'invalid entityType'
            });

        models[entityType].updateByPrimaryKey(entityId, updateObj, callback);
    },
};

module.exports = crudService;

//crudService.createEntity('cardMerchants', {
//    isBlocked: true,
//    merchantCategoryCode: "4121",
//    merchantId: "merchantId1",
//    merchantName: "My test merchant"
//}, function(err, results){
//      console.log("err here", err, results);
//});

//crudService.fetchDetails('cardMerchants', 'merchantId1', function(err, results){
//    console.log("err here", err, results);
//});
//
//crudService.fetchList('cardMerchants', {
//    isBlocked: true
//}, 2, 2, function(err, results){
//    console.log("err here", err, results);
//});


//crudService.updateEntity('cardMerchants', 'merchantId1', {$set: {
//    isBlocked: true,
//    "testUnknown": "this is new"
//}}, function(err, results){
//    console.log("err here", err, results);
//});

//crudService.deleteEntity('cardMerchants', 'merchantId1', function(err, results){
//    console.log("err here", err, results);
//});