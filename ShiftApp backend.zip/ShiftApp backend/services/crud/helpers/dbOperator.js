"use strict";
var async = require('async');
const monk = require('monk');

const nodeEnv = process.env.NODE_ENV || 'development';
var db;
var datadb;

class dbOperator {
    constructor (collection){
        this.collection = collection;
    }

    insert (objToInsert, beforeInsertHook, afterInsertHook, callback){
        var collection = db.get(this.collection);

        async.auto({
            beforeHook: function(cb){
                beforeInsertHook(objToInsert, cb);
            },
            main:['beforeHook', function(cb, results){
                collection.insert(objToInsert, cb);
            }],
            afterHook: ['main', function(cb, results){
                afterInsertHook(results.main, cb);
            }]
        }, function(err, results){
            if(err)
                return callback(err);

            return callback(null, results.main);
        });
    };

    find (findCritria, projectfields, skip, limit, callback){
        var collection = db.get(this.collection);

        collection.find(findCritria, {
            fields: projectfields,
            skip: skip,
            limit: limit
        }, function(err, matchedDocs){
            if(err)
                return callback(err);

            return callback(null, matchedDocs);
        });
    };

    update (findCriteria, updateCriteria, beforeUpdateHook, afterUpdateHook, callback) {
        var collection = db.get(this.collection);

        async.auto({
            beforeHook: function(cb){
                beforeUpdateHook(findCriteria, updateCriteria, cb);
            },
            main:['beforeHook', function(cb, results){
                collection.findAndModify(findCriteria, updateCriteria, {
                    new: 1
                }, cb);
            }],
            afterHook: ['main', function(cb, results){
                afterUpdateHook(results.main, cb);
            }]
        }, function(err, results){
            if(err)
                return callback(err);

            return callback(null, results.main);
        });
    };

    deleteRecord (findCriteria, callback) {
        var collection = db.get(this.collection);

        collection.remove(findCriteria, function(err, removedDocCount){
            if(err)
                return callback(err);

            return callback(null, removedDocCount);
        });
    };
}

module.exports = dbOperator;