"use strict";
var _ = require('underscore');
var Ajv = require('ajv');
var ajv = new Ajv();


var dbOperator = require('./../helpers/dbOperator');

function beforeInsertHook (obj, cb){ return cb();}
function afterInsertHook (obj, cb){ return cb();}
function beforeUpdateHook (obj1, obj2, cb){ return cb();}
function afterUpdateHook (obj, cb){ return cb();}

class models extends dbOperator {
    constructor (name, schema, hooks) {
        var projectfields = {};
        var updateableFields = [];
        super(name);
        this.name = name;
        this.schema = schema;
        this.primaryKey = _.find(Object.keys(schema.properties), function(key){
            return schema.properties[key].isPrimaryKey;
        });
        updateableFields.push(this.primaryKey);
        this.schemaValidator = ajv.compile(schema);

        _.each(Object.keys(schema.properties), function(key){
            if(schema.properties[key].readable)
                projectfields[key] = 1;

            if(schema.properties[key].readable)
                updateableFields.push(key);
        });

        this.projectfields = projectfields;
        this.updateableFields = updateableFields;

        beforeInsertHook = hooks.beforeInsert || beforeInsertHook;
        afterInsertHook = hooks.afterInsert || afterInsertHook;
        beforeUpdateHook = hooks.beforeUpdate || beforeUpdateHook;
        afterUpdateHook = hooks.afterUpdate || afterUpdateHook;
    }

    //returns object
    insert (obj, cb) {
        if(!this.schema.creatable)
            return cb({
                code: 'BAD_REQUEST',
                msg: 'operation not allowed on model'
            });

        var valid = this.schemaValidator(obj);
        if (!valid)
            return cb({
                code: 'BAD_REQUEST',
                msg: 'validation failed'
            });

        super.insert(obj, beforeInsertHook, afterInsertHook, cb);
    };

    //returns array of matching documents
    find (findCriteria, skip, limit, cb) {
        if(!this.schema.readable)
            return cb({
                code: 'BAD_REQUEST',
                msg: 'operation not allowed on model'
            });

        super.find(findCriteria, this.projectfields, skip, limit, cb);
    };

    //returns object, the one that is updated
    update (findCriteria, updateCriteria, cb) {
        if(!this.schema.updateable)
            return cb({
                code: 'BAD_REQUEST',
                msg: 'operation not allowed on model'
            });

        var updateF = {};

        _.each(Object.keys(updateCriteria), function(key){
            updateF[key] = _.pick(updateF[key], this.updateableFields);
        });

        if(Object.keys(updateF).length < 1)
            return cb({
                code: 'BAD_REQUEST',
                msg: 'nothing to update'
            });

        super.update(findCriteria, updateF, beforeUpdateHook, afterUpdateHook, cb);
    };

    //returns count of documents that were deleted
    deleteRecord (findCriteria, cb) {
        if(!this.schema.deleteable)
            return cb({
                code: 'BAD_REQUEST',
                msg: 'operation not allowed on model'
            });

        super.deleteRecord(findCriteria, cb);
    };

    findByPrimaryKey (id, cb) {
        if(!this.schema.readable)
            return cb({
                code: 'BAD_REQUEST',
                msg: 'operation not allowed on model'
            });

        var findCriteria = {};
        findCriteria[this.primaryKey] = id;
        super.find(findCriteria, this.projectfields, 0, 0, function(err, docArr){
            if(err)
                return cb(err);

            return cb(null, docArr[0]);
        });
    };

    deleteByPrimaryKey (id, cb) {
        if(!this.schema.deleteable)
            return cb({
                code: 'BAD_REQUEST',
                msg: 'operation not allowed on model'
            });

        var findCriteria = {};
        findCriteria[this.primaryKey] = id;
        super.deleteRecord(findCriteria, function(err, count){
            if(err)
                return cb(err);
            if(count < 1)
                return cb(null, {
                    deleted: false
                });

            return cb(null, {
                deleted: true
            });
        });
    };

    updateByPrimaryKey (id, updateCriteria, cb) {
        if(!this.schema.updateable)
            return cb({
                code: 'BAD_REQUEST',
                msg: 'operation not allowed on model'
            });

        var updateF = {};
        var allUpdateableFields = this.updateableFields;

        _.each(Object.keys(updateCriteria), function(key){
            updateF[key] = _.pick(updateCriteria[key], allUpdateableFields);
            if(Object.keys(updateF[key]).length < 1)
                delete updateF[key];
        });

        if(Object.keys(updateF).length < 1)
            return cb({
                code: 'BAD_REQUEST',
                msg: 'nothing to update'
            });

        var findCriteria = {};
        findCriteria[this.primaryKey] = id;
        super.update(findCriteria, updateF, beforeUpdateHook, afterUpdateHook, cb);
    }
}

module.exports = models;