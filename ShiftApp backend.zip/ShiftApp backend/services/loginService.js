var async = require('async');
var _ = require('underscore');
var jwt = require('jsonwebtoken');


var utils = require('./../services/utils');

var config = require('./../config');
var mongoDb = require('./../config/db').mongo;

var userTypeToCollectionMap = {
    'user': 'users',
};

var maxTries = {
    password_reset: 3
};

var loginService = {
    login: function(type, authObj, callback){

        if(!authObj.email || !authObj.password)
            return callback({
                code: "BAD_REQUEST",
                msg: "mandatory fields missing"
            });

        if(!userTypeToCollectionMap[type])
            return callback({
                code: "BAD_REQUEST",
                msg: "Invalid entity type"
            });

        var dbCol = mongoDb.get(userTypeToCollectionMap[type]);

        async.auto({
            findEntity: function(cb){
                dbCol.findOne({
                    email: authObj.email
                }, {}, function(err, entity){
                    if(err)
                        return cb(err);

                    if(!entity)
                        return cb({
                            code: 'BAD_REQUEST',
                            msg: 'username does not exist'
                        });

                    if(!utils.comparePassword(authObj.password, entity.password))
                        return cb({
                            code: 'BAD_REQUEST',
                            msg: 'Invalid password'
                        });

                    return cb(null, entity);
                });
            },
            generateToken: ['findEntity', function(results, cb){
                var accessToken = jwt.sign({
                    userId: results.findEntity.uuid
                }, config.CONSTANTS.jwtSecret, { expiresIn: '2h' });

                return cb(null, accessToken);
            }],
            updateToken: ['generateToken', function(results, cb){
                dbCol.findOneAndUpdate({
                    uuid: results.findEntity.uuid
                },{
                    $set: {
                        accessToken: results.generateToken,
                        updatedAt: new Date()
                    }
                },{}, function(err, updatedEntity){
                    if(err)
                        return cb(err);
                    return cb();
                });
            }]
        }, function(err, results){
            if(err)
                return callback(err);

            var toReturn = {
                accessToken: results.generateToken
            };

            return callback(null, toReturn);
        });
    },

    logout: function(type, entityObj, cb){
        if(!entityObj.uuid || !userTypeToCollectionMap[type])
            return cb({
                code: 'BAD_REQUEST',
                msg: 'Invalid Request'
            });

        var uuid = entityObj.uuid;
        var dbCol = mongoDb.get(userTypeToCollectionMap[type]);

        dbCol.findOneAndUpdate({
            uuid: uuid
        },{
            $unset: {
                accessToken: '',
                updatedAt: new Date()
            }
        },{}, function(err, updatedEntity){
            if(err)
                return cb(err);
            return cb(null, {
                logout: 'success'
            });
        });
    },

    initiateReset: function(type, username, callback){
        if(!userTypeToCollectionMap[type])
            return callback({
                code: "BAD_REQUEST",
                msg: "Invalid entity type"
            });

        var dbCol = mongoDb.get(userTypeToCollectionMap[type]);

        async.auto({
            findEntity: function(cb){
                dbCol.findOne({
                    $or:[{mobile: username}, {email: username}]
                }, {}, function(err, entity){
                    if(err)
                        return cb(err);

                    if(!entity)
                        return cb({
                            code: 'BAD_REQUEST',
                            msg: 'username does not exist'
                        });

                    return cb(null, entity);
                });
            },
            findOtp: ['findEntity', function(results, cb){
                var otpCol = mongoDb.get('otp');

                otpCol.findOne({
                    entity: type,
                    uuid: results.findEntity.uuid,
                    process: 'password_reset',
                    triesLeft: { $gt: 0}
                }, {}, function(err, otpDoc){
                    if(err)
                        return cb(err);

                    return cb(null, otpDoc);
                });
            }],
            setOtp: ['findEntity', 'findOtp', function(results, cb){
                if(results.findOtp)
                    return cb(null, results.findOtp);

                var otpCol = mongoDb.get('otp');

                var toInsert = {
                    entity: type,
                    username: username,
                    uuid: results.findEntity.uuid,
                    otp: utils.getIntOTP(5),
                    process: 'password_reset',
                    triesLeft: maxTries.password_reset,
                    createdAt: new Date(),
                };

                otpCol.insert(toInsert, function(err, otpDoc){
                    if(err)
                        return cb(err);
                    return cb(null, otpDoc);
                });
            }],
            sendEmail:['setOtp', function(results, cb){
                var emailData = {
                    name: results.findEntity.name,
                    otp: results.setOtp.otp,
                    reason: 'reset account password',
                };
                return cb();
            }]
        }, function(err, results){
            if(err)
                return callback(err);

            return callback(null, {
                resetInitate: 'success'
            });
        });
    },

    newPassword: function(type, username, otp, password, callback){
        if(!userTypeToCollectionMap[type])
            return callback({
                code: "BAD_REQUEST",
                msg: "Invalid entity type"
            });

        if(!utils.validatePassword(password))
            return callback({
                code: 'BAD_REQUEST',
                msg: 'Invalid password'
            });

        var dbCol = mongoDb.get(userTypeToCollectionMap[type]);

        async.auto({
            findEntity: function(cb){
                dbCol.findOne({
                    $or:[{mobile: username}, {email: username}]
                }, {}, function(err, entity){
                    if(err)
                        return cb(err);

                    if(!entity)
                        return cb({
                            code: 'BAD_REQUEST',
                            msg: 'username does not exist'
                        });

                    return cb(null, entity);
                });
            },
            checkOtp: ['findEntity', function(results, cb){
                var otpCol = mongoDb.get('otp');

                otpCol.findOneAndUpdate({
                    entity: type,
                    uuid: results.findEntity.uuid,
                    process: 'password_reset',
                    triesLeft: { $gt: 0}
                }, {
                    $inc: {
                        triesLeft: -1
                    }
                }, {}, function(err, otpDoc){
                    if(err)
                        return cb(err);

                    if(!otpDoc)
                        return cb({
                            code: 'BAD_REQUEST',
                            msg: 'password reset not initiated'
                        });

                    if(otpDoc.otp !== otp)
                        return cb({
                            code: 'BAD_REQUEST',
                            msg: 'Invalid OTP'
                        });

                    return cb(null, otpDoc);
                });
            }],
            setPassword: ['checkOtp', function(results, cb){

                var setPassword = utils.hashPassword(password);

                dbCol.findOneAndUpdate({
                    uuid: results.findEntity.uuid
                }, {
                    $set: {
                        password: setPassword
                    }
                }, {}, function(err, entityDoc){
                    if(err)
                        return cb(err);

                    return cb();
                });
            }],
            removeOtp: ['setPassword', function(results, cb){
                var otpCol = mongoDb.get('otp');
                otpCol.remove({
                    entity: type,
                    uuid: results.findEntity.uuid,
                    process: 'password_reset',
                }, function(err, otpRemoved){
                    if(err)
                        return cb(err);

                    return cb();
                });
            }],
        }, function(err, results){
            if(err)
                return callback(err);

            return callback(null, {
                passwordReset: 'success'
            });
        });

    },
};

module.exports = loginService;