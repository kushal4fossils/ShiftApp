var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var config = require('./config');
console.log("App starting in: ", config.ENV_NAME);

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var companyRouter = require('./routes/company');
var adminRouter = require('./routes/admin');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(function (req, res, next) {
  res.ok = function (resData) {
    res.status(200).send(resData);
  };
  res.created = function (resData) {
    res.status(201).send(resData);
  };
  res.noContent = function () {
    res.status(204).send();
  };
  res.badRequest = function (resData) {
    res.status(400).send(resData);
  };
  res.notAuthorized = function (resData) {
    res.status(401).send(resData);
  };
  res.notFound = function (resData) {
    res.status(404).send(resData);
  };
  res.serverError = function (resData) {
    if (resData) {
      res.status(500).send(resData);
    } else {
      res.status(500).send({
        status: "error",
        msg: "Something went wrong. Please try later."
      });
    }
  };
  res.sendError = function (err) {
    if (err.code && err.code === 'NOT_FOUND') {
      return res.notFound(err);
    }
    if (err.code && err.code === 'BAD_REQUEST') {
      return res.badRequest(err);
    }
    if (err.code && err.code === 'NOT_AUTHORIZED') {
      return res.notAuthorized(err);
    }
    if (err.code && err.code === 'BAD_REQUEST_CUSTOM') {
      err.status = "error";
      return res.ok(err);
    }
    return res.serverError(err);
  };
  next();
});

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/company', companyRouter);
app.use('/admin', adminRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
