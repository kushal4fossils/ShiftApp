# NodeChat

Experiment01: Web-based Real-time chat room app with nodejs socketio expressjs and mongodb.

**Install NodeJS (http://nodejs.org/)
**Install MongoDB (https://www.mongodb.com)

Then follow below steps:

1) Clone the repo and open terminal inside root folder and excute command 'npm install' to Install node modules from package.json  file
2) Create MongoDb 'chat' DB and add a 'messages' collection with this document structure '{"name":"","message":""}'
3) Run the server.js. (command -> node server.js) The server will listen on port 5000


**The provided code followed a tutorial of 'Codecourse' channel on youtube with a little from my side by separating CLIENT CODE in js folder and implementing ExpressJS to serve a static files and for future considerations..

Tut URL (https://goo.gl/7D5d62).
