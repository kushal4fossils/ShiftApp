module.exports = [
  {
    name: 'Rick',
    lastName: 'Grimes',
    statusText: 'I am the leader!',
    image: 'users/rick.jpg'
  },
  {
    name: 'Daryl',
    lastName: 'Dixon',
    statusText: 'I like smashing Walkers.',
    image: 'users/daryl.jpg'
  },
  {
    name: 'Carol',
    lastName: 'Peletier',
    statusText: 'Don\'t mess with me!',
    image: 'users/carol.jpg'
  },
  {
    name: 'Negan',
    lastName: '',
    statusText: 'In a relationship with Lucille.',
    image: 'users/negan.jpeg'
  }
]

