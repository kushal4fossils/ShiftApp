module.exports = [
  {
    name: 'Terminus',
    image: 'chatrooms/terminus.jpg'
  },
  {
    name: 'Alexandria',
    image: 'chatrooms/alexandria.jpg'
  },
  {
    name: 'Sanctuary',
    image: 'chatrooms/sanctuary.jpg'
  },
  {
    name: 'Hilltop',
    image: 'chatrooms/hilltop.jpg'
  }
]

