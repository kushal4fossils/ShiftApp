import React from 'react';

export default () => <h1> Loading </h1>
